// Pedimos al usuario su nombre

let nombreusuario = prompt("Cual es tu nombre: ");

// Declaramos la variable de la edad y edad valida en false

let edad;
let edadvalida = false;

// Creamos un bucle para que no se permitan letras en donde van numeros

while (!edadvalida) {
    let edadusuario = prompt("Cual es tu edad: ");
    edad = Number(edadusuario);

    // Validamos que los datos sean una entrada valida
    if (isNaN(edad)) {
        console.error("Por favor ingrese una edad válida con solo números");
        alert("La edad no es valida, ingrese de nuevo su edad: ");

    } else {
        edadvalida = true;
    }
}

// Imprimimos mensajes de acuerdo a la edad

if (edad < 18) {
    alert(`Hola ${nombreusuario}, tienes ${edad} años, por lo tanto eres menor de edad y no puedes entrar al programa`);
} else {
    alert(`Hola ${nombreusuario}, tienes ${edad} años. Bienvenido al programa`);
}

